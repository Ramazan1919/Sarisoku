﻿namespace DataAccesLayer.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ff : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Cars", "GunlukUcret", c => c.Int(nullable: false));
            AlterColumn("dbo.Cars", "IndirimOrani", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Cars", "IndirimOrani", c => c.Decimal(nullable: false, precision: 18, scale: 2));
            AlterColumn("dbo.Cars", "GunlukUcret", c => c.Decimal(nullable: false, precision: 18, scale: 2));
        }
    }
}
