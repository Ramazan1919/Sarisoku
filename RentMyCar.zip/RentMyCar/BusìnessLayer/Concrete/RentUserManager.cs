﻿using BusınessLayer.Abstract;
using DataEntity;

namespace BusınessLayer.Concrete
{
    public class RentUserManager : ManagerBase<RentUser>
    {

    }
}
