﻿using BusınessLayer.Abstract;
using DataEntity;

using System.Collections.Generic;

namespace BusınessLayer.Concrete
{
    public class CarManager : ManagerBase<Car>
    {


    }
}
