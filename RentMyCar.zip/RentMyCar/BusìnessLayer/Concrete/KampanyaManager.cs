﻿using BusınessLayer.Abstract;
using DataEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusınessLayer.Concrete
{
    public class KampanyaManager :ManagerBase<Kampanya>
    {
    }
}
